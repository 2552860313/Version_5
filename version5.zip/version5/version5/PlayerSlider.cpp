#include "PlayerSlider.h"

PlayerSlider::PlayerSlider(QWidget * parent) : QSlider(parent)
{
    m_bPressed = false;
}

void PlayerSlider::getplayer(ThePlayer* play){
    player=play;
}

void PlayerSlider::onTimerOut(){

    setValue( player->position()*100/player->duration());

}

void PlayerSlider::mousePressEvent(QMouseEvent *e)
{
    QSlider::mousePressEvent(e);
    double pos = e->pos().x() / (double)width();
    setValue(pos * (100 - 0) + 0);
    emit sliderPressed();
}

void PlayerSlider::setProgress(qint64 i64Progress) {
    if (!m_bPressed)
        setValue(i64Progress);
}


